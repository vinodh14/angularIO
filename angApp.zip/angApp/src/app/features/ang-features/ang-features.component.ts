import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-ang-features',
  templateUrl: './ang-features.component.html',
  styleUrls: ['./ang-features.component.css']
})
export class AngFeaturesComponent implements OnInit {
	@Input() features;
	constructor() { }

	ngOnInit() {

	}

}
