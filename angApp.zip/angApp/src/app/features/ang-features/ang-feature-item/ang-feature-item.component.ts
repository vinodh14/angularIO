import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-ang-feature-item',
  templateUrl: './ang-feature-item.component.html',
  styleUrls: ['./ang-feature-item.component.css']
})
export class AngFeatureItemComponent implements OnInit {
	@Input() featureItems;
	constructor() { }

	ngOnInit() {
	}

}
