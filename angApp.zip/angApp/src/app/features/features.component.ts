import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-features',
  templateUrl: './features.component.html',
  styleUrls: ['./features.component.css']
})
export class FeaturesComponent implements OnInit {
	features = [];
  constructor() { }

	ngOnInit() {
		this.features = [
			{
				featureHeader: 'CROSS PLATFORM',
				featureDetails: [
					{ 
						featureTitle: 'Progressive Web Apps',
						featureText: 'Use modern web platform capabilities to deliver app-like experiences. High performance, offline, and zero-step installation.'			
					},
					{ 
						featureTitle: 'Native',
						featureText: 'Build native mobile apps with strategies from Cordova, Ionic, or NativeScript.'			
					},
					{ 
						featureTitle: 'Desktop',
						featureText: 'Create desktop-installed apps across Mac, Windows, and Linux using the same Angular methods you\'ve learned for the web plus the ability to access native OS APIs.'			
					}
				]
			},
			{
				featureHeader: 'SPEED AND PERFORMANCE',
				featureDetails: [
					{ 
						featureTitle: 'Code Generation',
						featureText: 'Angular turns your templates into code that\'s highly optimized for today\'s JavaScript virtual machines, giving you all the benefits of hand-written code with the productivity of a framework.'			
					},
					{ 
						featureTitle: 'Native',
						featureText: 'Serve the first view of your application on Node.js®, .NET, PHP, and other servers for near-instant rendering in just HTML and CSS. Also paves the way for sites that optimize for SEO.'			
					},
					{ 
						featureTitle: 'Code Splitting',
						featureText: 'Angular apps load quickly with the new Component Router, which delivers automatic code-splitting so users only load code required to render the view they request.'			
					}
				]
			},
			{
				featureHeader: 'PRODUCTIVITY',
				featureDetails: [
					{ 
						featureTitle: 'Templates',
						featureText: 'Quickly create UI views with simple and powerful template syntax.'			
					},
					{ 
						featureTitle: 'Angular CLI',
						featureText: 'Command line tools: start building fast, add components and tests, then instantly deploy.'			
					},
					{ 
						featureTitle: 'IDEs',
						featureText: 'Get intelligent code completion, instant errors, and other feedback in popular editors and IDEs.'			
					}
				]
			},{
				featureHeader: 'FULL DEVELOPMENT STORY',
				featureDetails: [
					{ 
						featureTitle: 'Testing',
						featureText: 'With Karma for unit tests, you can know if you\'ve broken things every time you save. And Protractor makes your scenario tests run faster and in a stable manner.'			
					},
					{ 
						featureTitle: 'Animation',
						featureText: 'Create high-performance, complex choreographies and animation timelines with very little code through Angular\'s intuitive API.'			
					},
					{ 
						featureTitle: 'Accessibility',
						featureText: 'Create accessible applications with ARIA-enabled components, developer guides, and built-in a11y test infrastructure.'			
					}
				]
			}
		]
	}

}
