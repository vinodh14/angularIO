import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resources',
  templateUrl: './resources.component.html',
  styleUrls: ['./resources.component.css']
})
export class ResourcesComponent implements OnInit {
	angResources = [];
	constructor() { }

	ngOnInit() {
		this.angResources = [
			{
				resourceMainHeader: 'Development',
				resourceDetails: [
					{ 
						resourceSubHeader: 'IDEs',
						resourceSubDetails: [
							{
								resourceSubTitle: 'Amexio Canvas Web Based Drag and Drop IDE by MetaMagic',
								resourceDesc: 'Amexio Canvas is Drag and Drop Environment to create Fully Responsive Web and Smart Device HTML5/Angular Apps. Code will be auto generated and hot deployed by the Canvas for live testing. Out of the box 50+ Material Design Theme support. Commit your code to GitHub public or private repository.'
							},
							{
								resourceSubTitle: 'Angular IDE by Webclipse',
								resourceDesc: 'Built first and foremost for Angular. Turnkey setup for beginners; powerful for experts.'
							},
							{
								resourceSubTitle: 'IntelliJ IDEA',
								resourceDesc: 'Capable and Ergonomic Java * IDE'
							},
							{
								resourceSubTitle: 'Visual Studio Code',
								resourceDesc: 'VS Code is a Free, Lightweight Tool for Editing and Debugging Web Apps.'
							}					
						]		
					},
					{ 
						resourceSubHeader: 'Tooling',
						resourceSubDetails: [
							{
								resourceSubTitle: 'Angular CLI',
								resourceDesc: 'The official Angular CLI makes it easy to create and develop applications from initial commit to production deployment. It already follows our best practices right out of the box!'
							},
							{
								resourceSubTitle: 'Angular Playground',
								resourceDesc: 'UI development environment for building, testing, and documenting Angular applications.'
							},
							{
								resourceSubTitle: 'Angular Universal',
								resourceDesc: 'Server-side Rendering for Angular apps.'
							},
							{
								resourceSubTitle: 'Augury',
								resourceDesc: 'A Google Chrome Dev Tools extension for debugging Angular applications.'
							}					
						]		
					}
				]
			},
			{
				resourceMainHeader: 'Education',
				resourceDetails: [
					{ 
						resourceSubHeader: 'Books',
						resourceSubDetails: [
							{
								resourceSubTitle: 'Angular Router',
								resourceDesc: 'This book is a comprehensive guide to the Angular router written by its designer. The book explores the library in depth, including the mental model, design constraints, subtleties of the API.'
							},
							{
								resourceSubTitle: 'Angular-Buch (German)',
								resourceDesc: 'The first German book about Angular. It gives you a detailed practical overview of the key concepts of the platform. In each chapter a sample application is built upon with a new Angular topic. All sources are available on GitHub.'
							},
							{
								resourceSubTitle: 'Architecting Angular Applications with NGRX',
								resourceDesc: 'How to build Angular applications using NGRX'
							},
							{
								resourceSubTitle: 'Becoming a Ninja with Angular',
								resourceDesc: 'This ebook will help you getting the philosophy of the framework: what comes from 1.x, what has been introduced and why'
							}					
						]		
					},
					{ 
						resourceSubHeader: 'Workshops & Onsite Training',
						resourceSubDetails: [
							{
								resourceSubTitle: 'Accelebrate',
								resourceDesc: 'Customized, Instructor-Led Angular Training'
							},
							{
								resourceSubTitle: 'Angular Academy (Canada)',
								resourceDesc: 'Angular Academy is a two day hands-on public course given in-person across Canada!'
							},
							{
								resourceSubTitle: 'Angular Boot Camp',
								resourceDesc: 'Angular Boot Camp covers introductory through advanced Angular topics. It includes extensive workshop sessions, with hands-on help from our experienced developer-trainers. We take developers or teams from the beginnings of Angular understanding through a working knowledge of all essential Angular features.'
							},
							{
								resourceSubTitle: 'Angular Hands-on Course (Israel)',
								resourceDesc: 'Learn from 500Tech, an Angular consultancy in Israel. This course was built by an expert developer, who lives and breathes Angular, and has practical experience with real world large scale Angular apps.'
							}					
						]		
					}
				]
			},
			{
				resourceMainHeader: 'Community',
				resourceDetails: [
					{ 
						resourceSubHeader: 'Community Curations',
						resourceSubDetails: [
							{
								resourceSubTitle: 'Angular Conferences and Angular Camps in Moscow, Russia.',
								resourceDesc: 'Angular-RU Community on GitHub is a single entry point for all resources, chats, podcasts and meetups for Angular in Russia.'
							},
							{
								resourceSubTitle: 'Angular In Depth',
								resourceDesc: 'The place where advanced Angular concepts are explained'
							},
							{
								resourceSubTitle: 'Angular Subreddit',
								resourceDesc: 'An Angular-dedicated subreddit.'
							},
							{
								resourceSubTitle: 'Catalog of Angular Components & Libraries',
								resourceDesc: 'A community index of components and libraries maintained on GitHub'
							}					
						]		
					},
					{ 
						resourceSubHeader: 'Podcasts',
						resourceSubDetails: [
							{
								resourceSubTitle: 'Adventures in Angular',
								resourceDesc: 'Adventures in Angular is a weekly podcast dedicated to the Angular platform and related technologies, tools, languages, and practices.'
							},
							{
								resourceSubTitle: 'AngularAir',
								resourceDesc: 'Weekly video podcast hosted by Jeff Whelpley with all the latest and greatest happenings in the wild world of Angular.'
							},
							{
								resourceSubTitle: 'Happy Angular Podcast',
								resourceDesc: 'A weekly German podcast for Angular on the go'
							}				
						]		
					}
				]
			}
		]								
	}

}
