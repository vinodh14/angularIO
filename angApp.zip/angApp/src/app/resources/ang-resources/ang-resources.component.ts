import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-ang-resources',
  templateUrl: './ang-resources.component.html',
  styleUrls: ['./ang-resources.component.css']
})
export class AngResourcesComponent implements OnInit {
	@Input() angResources = [];
	constructor() { }

	ngOnInit() {
	}

}
