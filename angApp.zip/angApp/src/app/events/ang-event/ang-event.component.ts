import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-ang-event',
  templateUrl: './ang-event.component.html',
  styleUrls: ['./ang-event.component.css']
})
export class AngEventComponent implements OnInit {
	@Input() events = [];
	
	constructor() { }

	ngOnInit() {
	
	}

}
