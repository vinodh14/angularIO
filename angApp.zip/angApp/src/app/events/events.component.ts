import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css']
})
export class EventsComponent implements OnInit {

	eventsToPresent = [];
	eventsPresented = [];
	constructor() { }

	ngOnInit() {
		this.eventsToPresent = [
			{
				event: "NG-DE",
				location: "Berlin, Germany",
				date: "August 29th workshops, 30-31 conference, 2019"
			},
			{
				event: "AngularConnect",
				location: "London, UK",
				date: "September 19-20, 2019"
			},
			{
				event: "ReactiveConf",
				location: "Prague, Czech Republic",
				date: "Prague, Czech Republic"
			}
		]
		
		this.eventsPresented = [
			{
				event: "ng-japan",
				location: "Tokyo, Japan",
				date: "July 13, 2019"
			},
			{
				event: "ngVikings",
				location: "Copenhagen, Denmark",
				date: "May 26 (workshops), 27-28 (conference), 2019"
			},
			{
				event: "ng-conf",
				location: "Salt Lake City, Utah",
				date: "May 1-3, 2019"
			},
			{
				event: "ng-India",
				location: "Gurgaon, India",
				date: "February 23, 2019"
			},
			{
				event: "ngAtlanta",
				location: "Atlanta, Georgia",
				date: "January 9-12, 2019"
			}
		]
	}

}
