import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-home-promo',
  templateUrl: './home-promo.component.html',
  styleUrls: ['./home-promo.component.css']
})
export class HomePromoComponent implements OnInit {
	@Input() homePromos;

	constructor() { }

	ngOnInit() {
	
	}

}
