import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FeaturesComponent } from './features/features.component';
import { EventsComponent } from './events/events.component';
import { ResourcesComponent } from './resources/resources.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { HomePromoComponent } from './home/home-promo/home-promo.component';
import { AngFeaturesComponent } from './features/ang-features/ang-features.component';
import { AngFeatureItemComponent } from './features/ang-features/ang-feature-item/ang-feature-item.component';
import { AngResourcesComponent } from './resources/ang-resources/ang-resources.component';
import { AngEventComponent } from './events/ang-event/ang-event.component';

@NgModule({
  declarations: [
    AppComponent,
    FeaturesComponent,
    EventsComponent,
    ResourcesComponent,
    HeaderComponent,
    HomeComponent,
    HomePromoComponent,
    AngFeaturesComponent,
    AngFeatureItemComponent,
    AngResourcesComponent,
    AngEventComponent
  ],
  imports: [
    BrowserModule,
	BrowserAnimationsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
